#include "treasure.h"

std::vector<int> encode(std::vector<int> x,std::vector<int> y)
{
    return std::vector<int>();
}

std::vector<int> decode(std::vector<int> e)
{
    return std::vector<int>();
}
