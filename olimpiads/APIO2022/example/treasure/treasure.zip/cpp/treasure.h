#include <vector>

std::vector<int> encode(std::vector<int> x, std::vector<int> y);
std::vector<int> decode(std::vector<int> e);
