#include <vector>

void init(std::vector<int> a,std::vector<int> b);
bool can_convert(int l1,int r1,int l2,int r2);
