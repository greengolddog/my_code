#include <vector>

std::vector<int> use_machine(std::vector<int> v);
std::vector<int> guess_permutation(int n);
