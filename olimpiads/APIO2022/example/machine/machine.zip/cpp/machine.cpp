#include <bits/stdc++.h>
#include "machine.h"

std::vector<int> guess_permutation(int n)
{
	return std::vector<int>();
}