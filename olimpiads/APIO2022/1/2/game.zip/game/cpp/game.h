void init(int n, int k);
int add_teleporter(int u, int v);
