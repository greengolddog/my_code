#include "mars.h"

std::string process(std::vector <std::vector<std::string>> a, int i, int j, int k, int n)
{
	return std::string(100 ,'0');
}
